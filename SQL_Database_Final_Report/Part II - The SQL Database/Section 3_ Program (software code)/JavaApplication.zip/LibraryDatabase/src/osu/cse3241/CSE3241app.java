package osu.cse3241;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * <h1>CSE3241 Introduction to Database Systems - Sample Java application.</h1>
 *
 * <p>
 * Sample app to be used as guidance and a foundation for students of CSE3241
 * Introduction to Database Systems at The Ohio State University.
 * </p>
 *
 * <h2>!!! - Vulnerable to SQL injection - !!!</h2>
 * <p>
 * Correct the code so that it is not vulnerable to a SQL injection attack.
 * ("Parameter substitution" is the usual way to do this.)
 * </p>
 *
 * <p>
 * Class is written in Java SE 8 and in a procedural style. Implement a
 * constructor if you build this app out in OOP style.
 * </p>
 * <p>
 * Modify and extend this app as necessary for your project.
 * </p>
 *
 * <h2>Language Documentation:</h2>
 * <ul>
 * <li><a href="https://docs.oracle.com/javase/8/docs/">Java SE 8</a></li>
 * <li><a href="https://docs.oracle.com/javase/8/docs/api/">Java SE 8
 * API</a></li>
 * <li><a href=
 * "https://docs.oracle.com/javase/8/docs/technotes/guides/jdbc/">Java JDBC
 * API</a></li>
 * <li><a href="https://www.sqlite.org/docs.html">SQLite</a></li>
 * <li><a href="http://www.sqlitetutorial.net/sqlite-java/">SQLite Java
 * Tutorial</a></li>
 * </ul>
 *
 * <h2>MIT License</h2>
 *
 * <em>Copyright (c) 2019 Leon J. Madrid, Jeff Hachtel</em>
 *
 * <p>
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * </p>
 *
 *
 * @author Leon J. Madrid (madrid.1), Jeff Hachtel (hachtel.5), Sounak Dey
 *         (dey.77), Amanda Fleischer (fleischer.55)
 *
 */

public class CSE3241app {

    /**
     * The database file name.
     *
     * Make sure the database file is in the root folder of the project if you
     * only provide the name and extension.
     *
     * Otherwise, you will need to provide an absolute path from your C: drive
     * or a relative path from the folder this class is in.
     */
    private static String DATABASE = "LibraryDatabase.db";

    /**
     * Connects to the database if it exists, creates it if it does not, and
     * returns the connection object.
     *
     * @param databaseFileName
     *            the database file name
     * @return a connection object to the designated database
     */
    public static Connection initializeDB(String databaseFileName) {
        /**
         * The "Connection String" or "Connection URL".
         *
         * "jdbc:sqlite:" is the "subprotocol". (If this were a SQL Server
         * database it would be "jdbc:sqlserver:".)
         */
        String url = "jdbc:sqlite:" + databaseFileName;
        Connection conn = null; // If you create this variable inside the Try block it will be out of scope
        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                // Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out
                        .println("The driver name is " + meta.getDriverName());
                System.out.println(
                        "The connection to the database was successful.");
            } else {
                // Provides some feedback in case the connection failed but did not throw an exception.
                System.out.println("Null Connection");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out
                    .println("There was a problem connecting to the database.");
        }
        return conn;
    }

    /**
     * Queries the database and prints the results.
     *
     * @param conn
     *            a connection object
     * @param sql
     *            a SQL statement that returns rows This query is written with
     *            the Statement class, tipically used for static SQL SELECT
     *            statements
     */
    public static void sqlQuery(Connection conn, PreparedStatement stmt) {
        try {
            //Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String value = rsmd.getColumnName(i);
                System.out.print(value);
                if (i < columnCount) {
                    System.out.print(",  ");
                }
            }
            System.out.print("\n");
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = rs.getString(i);
                    System.out.print(columnValue);
                    if (i < columnCount) {
                        System.out.print(",  ");
                    }
                }
                System.out.print("\n");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        System.out.println("This is a new run");
        Connection conn = initializeDB(DATABASE);

        System.out.println(
                "*********************************************************************");

        int choice = 0;
        System.out.println(
                "Select one of the following options:\n1 - Enter new media\n2 - Edit media\n3 - Search media\n4 - Order items\n5 - Quit\nEnter option:");
        Scanner Scan = new Scanner(System.in);
        choice = Scan.nextInt();
        while (choice != 5) {
            switch (choice) {
                case 1:
                    choice = 1;
                    int addChoice = 0;
                    System.out.println(
                            "Please choose what new records to enter:\n1 - Album\n2 - Artist\n3 - Track\n4 - Movie\n5 - Director\n6 - Author\n7 - Audiobook\n");
                    addChoice = Scan.nextInt();
                    switch (addChoice) {
                        case 1:
                            addChoice = 1;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter album license (XXXXXXXXX-X): ");
                            String license = Scan.nextLine();
                            System.out.println(
                                    "Please enter album location (XXX.XXXX): ");
                            String location = Scan.nextLine();
                            System.out.println("Please enter album name: ");
                            String name = Scan.nextLine();
                            System.out.println("Please enter album genre: ");
                            String genre = Scan.nextLine();
                            System.out.println(
                                    "Please enter album record label (if none, enter NULL): ");
                            String record_label = Scan.nextLine();
                            System.out.println(
                                    "Please enter album length (in seconds): ");
                            Integer length = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter album year (YYYY): ");
                            Integer year = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter no. of physical copies: ");
                            Integer phys_copies = Integer
                                    .parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter no. of digital copies: ");
                            Integer online_copies = Integer
                                    .parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter the inventory ID (XXX-XX-XXXX): ");
                            String inventory_id = Scan.nextLine();

                            try {
                                String addInventory = "INSERT INTO CURRENT_INVENTORY VALUES (?);";
                                PreparedStatement stmt1 = conn
                                        .prepareStatement(addInventory);
                                stmt1.setString(1, inventory_id);
                                stmt1.executeUpdate();
                                System.out
                                        .println("Album added to inventory...");

                                String addMedia = "INSERT INTO MEDIA VALUES (?,?,?,?,?,?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addMedia);
                                stmt.setString(1, license);
                                stmt.setString(2, location);
                                stmt.setString(3, name);
                                stmt.setString(4, "Album");
                                stmt.setString(5, genre);
                                stmt.setInt(6, length);
                                stmt.setInt(7, year);
                                stmt.setInt(8, phys_copies);
                                stmt.setInt(9, online_copies);
                                stmt.setString(10, inventory_id);
                                stmt.executeUpdate();
                                System.out.println("Album added to Media...!");

                                String addAlbum = "INSERT INTO ALBUM VALUES (?,?);";
                                PreparedStatement stmt2 = conn
                                        .prepareStatement(addAlbum);
                                stmt2.setString(1, license);
                                stmt2.setString(2, record_label);
                                stmt2.executeUpdate();
                                System.out.println("Album added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 2:
                            addChoice = 2;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter artist ID (XXX-XX-XXXX): ");
                            String a_id = Scan.nextLine();
                            System.out.println("Please enter artist name: ");
                            name = Scan.nextLine();
                            try {
                                String addArtist = "INSERT INTO ARTIST VALUES (?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addArtist);
                                stmt.setString(1, a_id);
                                stmt.setString(2, name);
                                stmt.executeUpdate();
                                System.out.println("Artist added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:
                            addChoice = 3;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter the album license (XXXXXXXXX-X):");
                            license = Scan.nextLine();
                            System.out
                                    .println("Please enter the track number:");
                            Integer track_no = Integer
                                    .parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter track id (XXX-XX-XXXX):");
                            String id = Scan.nextLine();
                            System.out.println("Please enter track genre:");
                            genre = Scan.nextLine();
                            System.out.println(
                                    "Please enter track length (in seconds): ");
                            length = Integer.parseInt(Scan.nextLine());
                            System.out.println("Please enter track name: ");
                            name = Scan.nextLine();
                            System.out.println("Please enter track year: ");
                            year = Scan.nextInt();
                            System.out.println(
                                    "Please enter the feature artist id (XXX-XX-XXXX) if none, enter NULL: ");
                            String ft_id = Scan.nextLine();
                            try {
                                String addTrack = "INSERT INTO TRACK VALUES (?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addTrack);
                                stmt.setString(1, license);
                                stmt.setInt(2, track_no);
                                stmt.setString(3, name);
                                stmt.setInt(4, length);
                                stmt.setString(5, ft_id);
                                stmt.executeUpdate();
                                System.out.println("Track added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 4:
                            addChoice = 4;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter movie license (XXXXXXXXX-X): ");
                            license = Scan.nextLine();
                            System.out.println(
                                    "Please enter movie location (XXX.XXXX): ");
                            location = Scan.nextLine();
                            System.out.println("Please enter movie name: ");
                            name = Scan.nextLine();
                            System.out.println("Please enter movie genre: ");
                            genre = Scan.nextLine();
                            System.out.println(
                                    "Please enter movie length (in seconds): ");
                            length = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter movie year (YYYY): ");
                            year = Integer.parseInt(Scan.nextLine());
                            Scan.nextLine();
                            System.out.println("Please enter movie rating: ");
                            String rating = Scan.nextLine();
                            System.out.println(
                                    "Please enter no. of physical copies: ");
                            phys_copies = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter no. of digital copies: ");
                            online_copies = Integer.parseInt(Scan.nextLine());
                            System.out
                                    .println("Please enter the inventory id: ");
                            inventory_id = Scan.nextLine();

                            try {
                                String addInventory = "INSERT INTO CURRENT_INVENTORY VALUES (?);";
                                PreparedStatement stmt1 = conn
                                        .prepareStatement(addInventory);
                                stmt1.setString(1, inventory_id);
                                stmt1.executeUpdate();
                                System.out
                                        .println("Movie added to inventory...");

                                String addMedia = "INSERT INTO MEDIA VALUES (?,?,?,?,?,?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addMedia);
                                stmt.setString(1, license);
                                stmt.setString(2, location);
                                stmt.setString(3, name);
                                stmt.setString(4, "Movie");
                                stmt.setString(5, genre);
                                stmt.setInt(6, length);
                                stmt.setInt(7, year);
                                stmt.setInt(8, phys_copies);
                                stmt.setInt(9, online_copies);
                                stmt.setString(10, inventory_id);
                                stmt.executeUpdate();
                                System.out.println("Movie added to Media...!");

                                String addMovie = "INSERT INTO MOVIE VALUES (?,?);";
                                PreparedStatement stmt2 = conn
                                        .prepareStatement(addMovie);
                                stmt2.setString(1, license);
                                stmt2.setString(2, rating);
                                stmt2.executeUpdate();
                                System.out.println("Movie added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 5:
                            addChoice = 5;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter director ID (XXX-XX-XXXX): ");
                            String d_id = Scan.nextLine();
                            System.out.println(
                                    "Please enter director last name: ");
                            String Lname = Scan.nextLine();
                            System.out.println(
                                    "Please enter director first name: ");
                            String Fname = Scan.nextLine();
                            try {
                                String addDirector = "INSERT INTO DIRECTOR VALUES (?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addDirector);
                                stmt.setString(1, d_id);
                                stmt.setString(2, Lname);
                                stmt.setString(3, Fname);
                                stmt.executeUpdate();
                                System.out.println("Director added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 6:
                            addChoice = 6;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter author ID (XXX-XX-XXXX): ");
                            a_id = Scan.nextLine();
                            System.out
                                    .println("Please enter author last name: ");
                            Lname = Scan.nextLine();
                            System.out.println(
                                    "Please enter author first name: ");
                            Fname = Scan.nextLine();
                            try {
                                String addauthor = "INSERT INTO author VALUES (?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addauthor);
                                stmt.setString(1, a_id);
                                stmt.setString(2, Lname);
                                stmt.setString(3, Fname);
                                stmt.executeUpdate();
                                System.out.println("Author added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 7:
                            addChoice = 7;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter audiobook license (XXXXXXXXX-X): ");
                            license = Scan.nextLine();
                            System.out.println(
                                    "Please enter audiobook location (XXX.XXXX): ");
                            location = Scan.nextLine();
                            System.out.println("Please enter audiobook name: ");
                            name = Scan.nextLine();
                            System.out
                                    .println("Please enter audiobook genre: ");
                            genre = Scan.nextLine();
                            System.out.println(
                                    "Please enter audiobook length (in seconds): ");
                            length = Integer.parseInt(Scan.nextLine());
                            ;
                            System.out.println(
                                    "Please enter audiobook year (YYYY): ");
                            year = Integer.parseInt(Scan.nextLine());
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter number of chapters: ");
                            Integer chapters = Integer
                                    .parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter no. of physical copies: ");
                            phys_copies = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Please enter no. of digital copies: ");
                            online_copies = Integer.parseInt(Scan.nextLine());
                            System.out
                                    .println("Please enter the inventory id: ");
                            inventory_id = Scan.nextLine();

                            try {
                                String addInventory = "INSERT INTO CURRENT_INVENTORY VALUES (?);";
                                PreparedStatement stmt1 = conn
                                        .prepareStatement(addInventory);
                                stmt1.setString(1, inventory_id);
                                stmt1.executeUpdate();
                                System.out.println(
                                        "Audiobook added to inventory...");

                                String addMedia = "INSERT INTO MEDIA VALUES (?,?,?,?,?,?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addMedia);
                                stmt.setString(1, license);
                                stmt.setString(2, location);
                                stmt.setString(3, name);
                                stmt.setString(4, "Audiobook");
                                stmt.setString(5, genre);
                                stmt.setInt(6, length);
                                stmt.setInt(7, year);
                                stmt.setInt(8, phys_copies);
                                stmt.setInt(9, online_copies);
                                stmt.setString(10, inventory_id);
                                stmt.executeUpdate();
                                System.out.println(
                                        "Audiobook added to Media...!");

                                String addBook = "INSERT INTO AUDIOBOOK VALUES (?,?);";
                                PreparedStatement stmt2 = conn
                                        .prepareStatement(addBook);
                                stmt2.setString(1, license);
                                stmt2.setInt(2, chapters);
                                stmt2.executeUpdate();
                                System.out.println("Audiobook added!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }
                    break;
                case 2:
                    choice = 2;
                    int editChoice = 0;
                    System.out.println(
                            "Please choose what media to edit:\n1 - Album\n2 - Movie\n3 - Audiobook");
                    editChoice = Scan.nextInt();
                    switch (editChoice) {
                        case 1:
                            editChoice = 1;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter album license (XXXXXXXXX-X): ");
                            String license = Scan.nextLine();
                            String searchAlbum = "SELECT name,year FROM MEDIA WHERE license = ?;";
                            try {
                                PreparedStatement stmt = conn
                                        .prepareStatement(searchAlbum);
                                stmt.setString(1, license);
                                sqlQuery(conn, stmt);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            System.out.println(
                                    "Is this the record you would like to edit? (Enter 1 for yes, enter 0 for no)");
                            int c = Scan.nextInt();
                            if (c == 1) {
                                System.out.println(
                                        "Would you like to edit this record or delete it? (Enter 1 to edit, enter 0 to delete)");
                                c = Scan.nextInt();
                                if (c == 1) {
                                    System.out.println(
                                            "Please enter updated field values:");
                                    Scan.nextLine();
                                    System.out.println(
                                            "Please enter album license (XXXXXXXXX-X): ");
                                    license = Scan.nextLine();
                                    System.out.println(
                                            "Please enter album location (XXX.XXXX): ");
                                    String location = Scan.nextLine();
                                    System.out.println(
                                            "Please enter album name: ");
                                    String name = Scan.nextLine();
                                    System.out.println(
                                            "Please enter album genre: ");
                                    String genre = Scan.nextLine();
                                    System.out.println(
                                            "Please enter album record label (if none, enter NULL): ");
                                    String record_label = Scan.nextLine();
                                    System.out.println(
                                            "Please enter album length (in seconds): ");
                                    Integer length = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter album year (YYYY): ");
                                    Integer year = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter no. of physical copies: ");
                                    Integer phys_copies = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter no. of digital copies: ");
                                    Integer online_copies = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter the inventory ID: ");
                                    String inventory_id = Scan.nextLine();
                                    try {
                                        String updateMedia = "UPDATE MEDIA SET license=?, location=?, name=?, description=?, genre=?, length=?, year=?, num_phys_avail=?, num_online_avail=?, inventory_id=?;";
                                        PreparedStatement stmt = conn
                                                .prepareStatement(updateMedia);
                                        stmt.setString(1, license);
                                        stmt.setString(2, location);
                                        stmt.setString(3, name);
                                        stmt.setString(4, "Album");
                                        stmt.setString(5, genre);
                                        stmt.setInt(6, length);
                                        stmt.setInt(7, year);
                                        stmt.setInt(8, phys_copies);
                                        stmt.setInt(9, online_copies);
                                        stmt.setString(10, inventory_id);
                                        stmt.executeUpdate();
                                        System.out.println(
                                                "Album updated in Media...!");

                                        String updateAlbum = "UPDATE ALBUM SET license=?, record_label=?;";
                                        PreparedStatement stmt2 = conn
                                                .prepareStatement(updateAlbum);
                                        stmt2.setString(1, license);
                                        stmt2.setString(2, record_label);
                                        stmt2.executeUpdate();
                                        System.out.println("Album updated!");
                                    } catch (SQLException e) {
                                        System.out.println(e.getMessage());
                                    }
                                } else {
                                    try {
                                        String delTrack = "DELETE FROM TRACK WHERE album_license=?;";
                                        PreparedStatement stmt = conn
                                                .prepareStatement(delTrack);
                                        stmt.setString(1, license);
                                        stmt.executeUpdate();
                                        System.out.println(
                                                "Album tracks deleted...");

                                        String delAlbum = "DELETE FROM ALBUM WHERE license=?;";
                                        PreparedStatement stmt1 = conn
                                                .prepareStatement(delAlbum);
                                        stmt1.setString(1, license);
                                        stmt1.executeUpdate();
                                        System.out.println("Album deleted!");
                                    } catch (SQLException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                            }
                            break;
                        case 2:
                            editChoice = 2;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter movie license (XXXXXXXXX-X): ");
                            license = Scan.nextLine();
                            String searchMovie = "SELECT name,year FROM MEDIA WHERE license = ?;";
                            try {
                                PreparedStatement stmt = conn
                                        .prepareStatement(searchMovie);
                                stmt.setString(1, license);
                                sqlQuery(conn, stmt);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            System.out.println(
                                    "Is this the record you would like to edit? (Enter 1 for yes, enter 0 for no)");
                            c = Scan.nextInt();
                            if (c == 1) {
                                System.out.println(
                                        "Would you like to edit this record or delete it? (Enter 1 to edit, enter 0 to delete)");
                                c = Scan.nextInt();
                                if (c == 1) {
                                    System.out.println(
                                            "Please enter updated field values:");
                                    Scan.nextLine();
                                    System.out.println(
                                            "Please enter movie license (XXXXXXXXX-X): ");
                                    license = Scan.nextLine();
                                    System.out.println(
                                            "Please enter movie location (XXX.XXXX): ");
                                    String location = Scan.nextLine();
                                    System.out.println(
                                            "Please enter movie name: ");
                                    String name = Scan.nextLine();
                                    System.out.println(
                                            "Please enter movie genre: ");
                                    String genre = Scan.nextLine();
                                    System.out.println(
                                            "Please enter movie rating: ");
                                    String rating = Scan.nextLine();
                                    System.out.println(
                                            "Please enter movie length (in seconds): ");
                                    Integer length = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter movie year (YYYY): ");
                                    Integer year = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter no. of physical copies: ");
                                    Integer phys_copies = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter no. of digital copies: ");
                                    Integer online_copies = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter the inventory ID: ");
                                    String inventory_id = Scan.nextLine();
                                    try {
                                        String updateMedia = "UPDATE MEDIA SET license=?, location=?, name=?, description=?, genre=?, length=?, year=?, num_phys_avail=?, num_online_avail=?, inventory_id=?;";
                                        PreparedStatement stmt = conn
                                                .prepareStatement(updateMedia);
                                        stmt.setString(1, license);
                                        stmt.setString(2, location);
                                        stmt.setString(3, name);
                                        stmt.setString(4, "Movie");
                                        stmt.setString(5, genre);
                                        stmt.setInt(6, length);
                                        stmt.setInt(7, year);
                                        stmt.setInt(8, phys_copies);
                                        stmt.setInt(9, online_copies);
                                        stmt.setString(10, inventory_id);
                                        stmt.executeUpdate();
                                        System.out.println(
                                                "Movie updated in Media...!");

                                        String updateAlbum = "UPDATE MOVIE SET license=?, rating=?;";
                                        PreparedStatement stmt2 = conn
                                                .prepareStatement(updateAlbum);
                                        stmt2.setString(1, license);
                                        stmt2.setString(2, rating);
                                        stmt2.executeUpdate();
                                        System.out.println("Movie updated!");
                                    } catch (SQLException e) {
                                        System.out.println(e.getMessage());
                                    }
                                } else {
                                    try {
                                        String delMedia = "DELETE FROM MEDIA WHERE license=?;";
                                        PreparedStatement stmt = conn
                                                .prepareStatement(delMedia);
                                        stmt.setString(1, license);
                                        stmt.executeUpdate();
                                        System.out.println(
                                                "Movie deleted from media...");

                                        String delMovie = "DELETE FROM MOVIE WHERE license=?;";
                                        PreparedStatement stmt1 = conn
                                                .prepareStatement(delMovie);
                                        stmt1.setString(1, license);
                                        stmt1.executeUpdate();
                                        System.out.println("Movie deleted!");
                                    } catch (SQLException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                            }
                            break;
                        case 3:
                            editChoice = 3;
                            Scan.nextLine();
                            System.out.println(
                                    "Please enter audiobook license (XXXXXXXXX-X): ");
                            license = Scan.nextLine();
                            String searchBook = "SELECT name,year FROM MEDIA WHERE license = ?;";
                            try {
                                PreparedStatement stmt = conn
                                        .prepareStatement(searchBook);
                                stmt.setString(1, license);
                                sqlQuery(conn, stmt);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            System.out.println(
                                    "Is this the record you would like to edit? (Enter 1 for yes, enter 0 for no)");
                            c = Scan.nextInt();
                            if (c == 1) {
                                System.out.println(
                                        "Would you like to edit this record or delete it? (Enter 1 to edit, enter 0 to delete)");
                                c = Scan.nextInt();
                                if (c == 1) {
                                    System.out.println(
                                            "Please enter updated field values:");
                                    Scan.nextLine();
                                    System.out.println(
                                            "Please enter audiobook license (XXXXXXXXX-X): ");
                                    license = Scan.nextLine();
                                    System.out.println(
                                            "Please enter audiobook location (XXX.XXXX): ");
                                    String location = Scan.nextLine();
                                    System.out.println(
                                            "Please enter audiobook name: ");
                                    String name = Scan.nextLine();
                                    System.out.println(
                                            "Please enter audiobook genre: ");
                                    String genre = Scan.nextLine();
                                    System.out.println(
                                            "Please enter number of chapters: ");
                                    int chapters = Scan.nextInt();
                                    System.out.println(
                                            "Please enter audiobook length (in seconds): ");
                                    Integer length = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter audiobook year (YYYY): ");
                                    Integer year = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter no. of physical copies: ");
                                    Integer phys_copies = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter no. of digital copies: ");
                                    Integer online_copies = Integer
                                            .parseInt(Scan.nextLine());
                                    System.out.println(
                                            "Please enter the inventory ID: ");
                                    String inventory_id = Scan.nextLine();
                                    try {
                                        String updateMedia = "UPDATE MEDIA SET license=?, location=?, name=?, description=?, genre=?, length=?, year=?, num_phys_avail=?, num_online_avail=?, inventory_id=?;";
                                        PreparedStatement stmt = conn
                                                .prepareStatement(updateMedia);
                                        stmt.setString(1, license);
                                        stmt.setString(2, location);
                                        stmt.setString(3, name);
                                        stmt.setString(4, "Audiobook");
                                        stmt.setString(5, genre);
                                        stmt.setInt(6, length);
                                        stmt.setInt(7, year);
                                        stmt.setInt(8, phys_copies);
                                        stmt.setInt(9, online_copies);
                                        stmt.setString(10, inventory_id);
                                        stmt.executeUpdate();
                                        System.out.println(
                                                "Audiobook updated in Media...!");

                                        String updateAlbum = "UPDATE MOVIE SET license=?, rating=?;";
                                        PreparedStatement stmt2 = conn
                                                .prepareStatement(updateAlbum);
                                        stmt2.setString(1, license);
                                        stmt2.setInt(2, chapters);
                                        stmt2.executeUpdate();
                                        System.out
                                                .println("Audiobook updated!");
                                    } catch (SQLException e) {
                                        System.out.println(e.getMessage());
                                    }
                                } else {
                                    try {
                                        String delMedia = "DELETE FROM MEDIA WHERE license=?;";
                                        PreparedStatement stmt = conn
                                                .prepareStatement(delMedia);
                                        stmt.setString(1, license);
                                        stmt.executeUpdate();
                                        System.out.println(
                                                "Audiobook deleted from Media...");

                                        String delMovie = "DELETE FROM AUDIOBOOK WHERE license=?;";
                                        PreparedStatement stmt1 = conn
                                                .prepareStatement(delMovie);
                                        stmt1.setString(1, license);
                                        stmt1.executeUpdate();
                                        System.out
                                                .println("Audiobook deleted!");
                                    } catch (SQLException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                            }
                    }
                    break;
                case 3:
                    choice = 3;
                    int searchChoice = 0;
                    System.out.println(
                            "Please choose which media you would like to search for:\n1 - Album\n2 - Movie\n3 - Audiobook");
                    searchChoice = Scan.nextInt();
                    switch (searchChoice) {
                        case 1:
                            searchChoice = 1;
                            Scan.nextLine();

                            String searchAlbum = "SELECT name,year FROM ALBUM, MEDIA WHERE ALBUM.license = MEDIA.license;";
                            try {
                                PreparedStatement stmt = conn
                                        .prepareStatement(searchAlbum);
                                sqlQuery(conn, stmt);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }

                            break;
                        case 2:
                            searchChoice = 2;
                            Scan.nextLine();

                            String searchMovie = "SELECT name,year FROM MOVIE, MEDIA WHERE MOVIE.license = MEDIA.license;";
                            try {
                                PreparedStatement stmt = conn
                                        .prepareStatement(searchMovie);
                                sqlQuery(conn, stmt);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:
                            searchChoice = 3;
                            Scan.nextLine();

                            String searchBook = "SELECT name,year FROM AUDIOBOOK, MEDIA WHERE AUDIOBOOK.license = MEDIA.license;";
                            try {
                                PreparedStatement stmt = conn
                                        .prepareStatement(searchBook);
                                sqlQuery(conn, stmt);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        default:
                            System.out.println("Invalid choice");
                    }
                    break;
                case 4:
                    choice = 4;
                    Scan.nextLine();
                    System.out.println(
                            "Please choose which media you would like to order:\n1 - Album\n2 - Movie\n3 - Audiobook");
                    int orderChoice = Scan.nextInt();
                    switch (orderChoice) {
                        case 1: //Album
                            orderChoice = 1;
                            Scan.nextLine();

                            int receipt_no = (int) Math.floor(
                                    Math.random() * (499999999 - 1000000000 + 1)
                                            + 1000000000); //random receipt number
                            String receipt = Integer.toString(receipt_no);

                            System.out.println(
                                    "Enter the name of the Album you'd like to order:");
                            String name = Scan.nextLine();
                            System.out.println(
                                    "Enter the number of copies you wish to order:");
                            Integer copies = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Enter the date in which you wish to receive the order by (YYYY-MM-DD):");
                            String date = Scan.nextLine();

                            try {
                                String addOrder = "INSERT INTO ITEMS_ORDERED VALUES (?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addOrder);
                                stmt.setString(1, receipt);
                                stmt.setDate(2, java.sql.Date.valueOf(date));
                                stmt.setString(3, "Album");
                                stmt.setString(4, name);
                                stmt.setInt(5, copies);
                                stmt.executeUpdate();
                                System.out
                                        .println("Your order has been placed!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 2: //Movie
                            orderChoice = 2;
                            Scan.nextLine();

                            receipt_no = (int) Math.floor(
                                    Math.random() * (499999999 - 1000000000 + 1)
                                            + 1000000000); //random receipt number
                            receipt = Integer.toString(receipt_no);

                            System.out.println(
                                    "Enter the name of the Movie you'd like to order:");
                            name = Scan.nextLine();
                            System.out.println(
                                    "Enter the number of copies you wish to order:");
                            copies = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Enter the date in which you wish to receive the order by (YYYY-MM-DD):");
                            date = Scan.nextLine();

                            try {
                                String addOrder = "INSERT INTO ITEMS_ORDERED VALUES (?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addOrder);
                                stmt.setString(1, receipt);
                                stmt.setDate(2, java.sql.Date.valueOf(date));
                                stmt.setString(3, "Movie");
                                stmt.setString(4, name);
                                stmt.setInt(5, copies);
                                stmt.executeUpdate();
                                System.out
                                        .println("Your order has been placed!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 3: //Audiobook
                            orderChoice = 3;
                            Scan.nextLine();

                            receipt_no = (int) Math.floor(
                                    Math.random() * (499999999 - 1000000000 + 1)
                                            + 1000000000); //random receipt number
                            receipt = Integer.toString(receipt_no);

                            System.out.println(
                                    "Enter the name of the Audiobook you'd like to order:");
                            name = Scan.nextLine();
                            System.out.println(
                                    "Enter the number of copies you wish to order:");
                            copies = Integer.parseInt(Scan.nextLine());
                            System.out.println(
                                    "Enter the date in which you wish to receive the order by (YYYY-MM-DD):");
                            date = Scan.nextLine();

                            try {
                                String addOrder = "INSERT INTO ITEMS_ORDERED VALUES (?,?,?,?,?);";
                                PreparedStatement stmt = conn
                                        .prepareStatement(addOrder);
                                stmt.setString(1, receipt);
                                stmt.setDate(2, java.sql.Date.valueOf(date));
                                stmt.setString(3, "Audiobook");
                                stmt.setString(4, name);
                                stmt.setInt(5, copies);
                                stmt.executeUpdate();
                                System.out
                                        .println("Your order has been placed!");
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        default:
                            System.out.println("Invalid Choice");
                    }
                    break;
                case 5:
                    choice = 5;

                    System.out.println("Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice");

            }
            System.out.println(
                    "Select one of the following options:\n1 - Enter new media\n2 - Edit media\n3 - Search media\n4 - Order items\n5 - Quit\nEnter option:");
            choice = Scan.nextInt();
        }

        System.out.println(
                "*********************************************************************");

        /*
         * finally best approach finally{
         *
         * /* From JSE7 onwards the try-with-resources statement is introduced.
         * The resources in the try block will be closed automatically after the
         * use, at the end of the try block close JDBC objects If not, use the
         * following block: try { if(rs!=null) rs.close(); } catch (SQLException
         * se) { se.printStackTrace(); } try { if(stmt !=null) st.close(); }
         * catch (SQLException se) { se.printStackTrace(); } try { if(conn
         * !=null) con.close(); } catch (SQLException se) {
         * se.printStackTrace(); } }
         */
    }
}
